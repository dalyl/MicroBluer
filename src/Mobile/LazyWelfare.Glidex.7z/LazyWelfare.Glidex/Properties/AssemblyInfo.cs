﻿using System.Reflection;
using System.Runtime.InteropServices;
using Android;

[assembly: AssemblyTitle ("glidex")]
[assembly: AssemblyDescription ("")]
[assembly: AssemblyConfiguration ("")]
[assembly: AssemblyCompany ("Jonathan Peppers")]
[assembly: AssemblyProduct ("glidex")]
[assembly: AssemblyCopyright ("Copyright © Jonathan Peppers 2018")]
[assembly: AssemblyTrademark ("")]
[assembly: AssemblyCulture ("")]
[assembly: ComVisible (false)]
[assembly: AssemblyVersion ("4.6.1.0")]
[assembly: AssemblyFileVersion ("4.6.1.0")]
[assembly: LinkerSafe]